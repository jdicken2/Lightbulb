package lightbulbs;
//import edu.iit.button;
public class Lightbulb 
{
	//String stdout="nothing";
	public Lightbulb()
	{

	}

	public void on()
	{
		System.out.println("Lightbulb on");
		//return stdout;
	}

	public void off()
	{
		System.out.println("Lightbulb off");
		//return stdout;
	}

} 